

function LaCasa() {
    return(
        <div className="container">
            <div className="row">
                <div className="col-md-4">
                    <h2>La Casa</h2>
                    <a href="#">La Casa</a>
                </div>
            </div>
        </div>
    );
};

export default LaCasa;